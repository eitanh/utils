import subprocess
def login():
    subprocess.run(["powershell","az login"])