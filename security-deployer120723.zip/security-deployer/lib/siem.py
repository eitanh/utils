import subprocess
import yaml
from yaml.loader import SafeLoader
from lib.spin import spin
from rich.console import Console
from rich import print, pretty
import json
import pyfiglet


def check_if_siem_function_exist(functionAppName):
    console = Console()
    cmd="cd siem-connector;func azure functionapp list-functions "+functionAppName
    with console.status("[bold green]Checking for existing SIEM Connector...") as status:
        out=subprocess.run(["powershell",cmd],stdout=subprocess.PIPE)
        if b'IncidentQuery ' in out.stdout:
            print(f'[bold][green]Function already exist, updating new version')
            return True
        print(f'[bold][green]Function not found, Creating it')
        return False

def install_siem_function():
    console = Console()
    pretty.install()
    with open('config.yaml') as f:
         data = yaml.load(f, Loader=SafeLoader)
         functionAppName=data["SiemFunctionAppName"]
    exist=check_if_siem_function_exist(functionAppName)
    if exist:
        text="Updating SIEM Connector"
        print(text+" to function app "+functionAppName)
    else:
        text="Installing SIEM Connector"
        print(text+" to function app "+functionAppName)
    spin(5)
    cmd="cd siem-connector;func azure functionapp publish "+functionAppName+" --python"
    process =subprocess.Popen(["powershell",cmd],stdout=subprocess.PIPE, text=True)
    out=[]
    with console.status("[bold green]"+text+"...") as status:

        while True:
            output = process.stdout.readline()
            
            if output == '' and process.poll() is not None:
                break
            if output:
                out.append(output)
                print (output.strip())
        
        check1="Deployment successful"
        check2="Remote build succeeded"
        flag1=False
        flag2=False
        for line in out:
            if check1 in line:
                flag1 = True
            if check2 in line:
                flag2 = True
        
        if flag1 and flag2:
            print(f'[bold][green]-------------=============== Function Successfuly Deployed ==============----------------------')
            return True
        else:
            console.log(f'[bold][red]-------------============ Error Deploying Function Please Check Log ===========----------------------')
            return False

def config_siem_params():
    console = Console()
    pretty.install()
    with open('config.yaml') as f:
        data = yaml.load(f, Loader=SafeLoader)
        functionAppName=data["SiemFunctionAppName"]
        rg=data["SiemFunctionResourceGroup"]
        sa=data["SiemFunctionStorageAccountName"]
        container=data["SiemFunctionStorageAccountName"]
        log_analytics_ws=data["SiemFunctionLogAnalyticsWorkspace"]
        timefix=data["SiemFunctionTimeFix"]
        account=data["AccountName"]
       
    cmd1="az functionapp config appsettings list --resource-group "+rg+" --name "+functionAppName
    cmd2='az functionapp config appsettings set --name '+functionAppName+' --resource-group '+rg+' --settings "ACCOUNT='+account+'"'
    cmd3='az functionapp config appsettings set --name '+functionAppName+' --resource-group '+rg+' --settings "CONTAINER='+container+'"'
    cmd4='az functionapp config appsettings set --name '+functionAppName+' --resource-group '+rg+' --settings "LogAnalyticsWorkspace='+log_analytics_ws+'"'
    cmd5='az functionapp config appsettings set --name '+functionAppName+' --resource-group '+rg+' --settings "STORAGE_ACCOUNT='+sa+'"'
    cmd6='az functionapp config appsettings set --name '+functionAppName+' --resource-group '+rg+' --settings "TIMEFIX='+str(timefix)+'"'



    with console.status("[bold green]Configuring Function Params...") as status:
        out1=subprocess.run(["powershell",cmd2],stdout=subprocess.PIPE)
        out2=subprocess.run(["powershell",cmd3],stdout=subprocess.PIPE)
        out3=subprocess.run(["powershell",cmd4],stdout=subprocess.PIPE)
        out4=subprocess.run(["powershell",cmd5],stdout=subprocess.PIPE)
        out5=subprocess.run(["powershell",cmd6],stdout=subprocess.PIPE)
    print(f'[bold][green]-------------=============== Function Params Successfuly Configured  ==============----------------------')
    return True

def deploy_siem_connector():
    success=install_siem_function()
    if not success:
        return
    sucess=config_siem_params()
    
    banner = pyfiglet.Figlet(font='slant')
    print(banner.renderText('Done'))
