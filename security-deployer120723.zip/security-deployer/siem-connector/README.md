# Incidents and entities adaptor for Arcsight CEF

Configuration:

TIMEFIX - parameter to control time fix adjusted to the destination.\
CONTAINER - the destination container\
STORAGE_ACCOUNT - the destination storage account.\
ACCOUNT - the account name\
AZURE_CLIENT_ID - principal id\
AZURE_CLIENT_SECRET - principal secret\
AZURE_TENANT_ID - tenant id\
\
principal - logicapp-security\
permissions: \
  a. contributor/reader on log analytics\
  b. Storage Blob Data Owner / writer on the storage account\
