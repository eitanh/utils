import logging
import pandas as pd
import re
import os
from datetime import timezone,timedelta,datetime
from .blob import writeToBlob

def fix_date(mydate):
    m=mydate.split()
    num=m[0]
    if num=='1' or num=='01':
        month= "Jan"
    if num=='2' or num=='02':
       month= "Feb"
    if num=='3' or num=='03':
       month= "Mar"
    if num=='4' or num=='04':
       month= "Apr"
    if num=='5' or num=='05':
       month= "May"
    if num=='6' or num=='06':
       month= "Jul"
    if num=='7' or num=='07':
       month= "Jun"
    if num=='8' or num=='08':
       month= "Aug"
    if num=='9' or num=='09':
       month= "Sep"
    if num=='10':
       month= "Oct"
    if num=='11':
       month= "Nov"
    if num=='12':
       month= "Dec"
    result= re.sub(r'^\d+',month,mydate)
    return result
def process(response):
    logging.info("Going to show response1")
    data_for_file=""
    count=0
    for table in response:
        #logging.info("rows are "+str(table.rows))
        df = pd.DataFrame(table.rows, columns=table.columns)
        
        for index, row in df.iterrows():
            mydate=fix_date(row['TimeGenerated'])
            try:
            #  mydateO = datetime.strptime(mydate, '%b %d %Y %H:%M:%S')
            #  mydateO=mydateO+timedelta(hours=2)
            #  try:
            #    mydateZ=fix_date(mydateO)
            #    logging.info("FIXED DATE "+str(mydateZ))
            # except:
            #    logging.info("Error with FIXED DATE "+str(mydateZ))
             #datetime.datetime.strptime('Mon Feb 15 2010', '%a %b %d %Y').strftime('%d/%m/%Y')
             #newdt1=datetime.datetime.strptime(str(mydate), '%b %d %Y %H:%M:%S')
             conv=datetime.strptime(str(mydate), '%b %d %Y %H:%M:%S')
             hours_fix=int(os.environ['TIMEFIX'])
             newdata1=conv+timedelta(hours=hours_fix)
             newdate1=newdata1.strftime('%b %d %Y %H:%M:%S')
             logging.info ("MYDATE: "+str(mydate))
             logging.info ("NEWDATE1: "+str(newdate1))
             
             cef_data="CEF:0|Sentinel|"+os.environ['ACCOUNT']+"|||"+row['Title']+"|"+row['AlertSeverity']+"|src="+row['SenderIP']+" end="+str(newdate1).upper()+" cs1Label=ip cs1="+row['IpAddress']+" cs2Label=user cs2="+row['UserDisplayName']+" cs3Label=userDisplayName cs3="+row['UserDisplayName']+" dhost="+row['HostName']+" fname="+row['FileName']+" fileHash="+row['FileHash']
             logging.info ("DATA: "+cef_data)
            except:
               logging.info("Failed "+str(datetime.strptime(mydate, '%b %d %Y %H:%M:%S')))
            count+=1
            #cef_data="CEF:0|Sentinel|"+os.environ['ACCOUNT']+"|||"+row['Title']+"|"+row['AlertSeverity']+"|src="+row['SenderIP']+" end="+mydate+" cs1Label=ip cs1="+row['IpAddress']+" cs2Label=user cs2="+row['UserDisplayName']+" cs3Label=userDisplayName cs3="+row['UserDisplayName']+" dhost="+row['HostName']+" fname="+row['FileName']+" fileHash="+row['FileHash']
            print(cef_data)
            logging.info(cef_data)
            data_for_file+=cef_data+"\n"

    logging.info("found "+str(count)+" records")
    if count==0:
      data_for_file="CEF:0|Sentinel|"+os.environ['ACCOUNT']+"|||heartbeat||"
    writeToBlob(data_for_file)        