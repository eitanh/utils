from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from azure.identity import DefaultAzureCredential
import logging
import os
from datetime import datetime, timedelta



def writeToBlob(data):
    if data!="":
        logging.info("starting write to blob 1.0.6")
        logging.info(data)
        account_url = "https://"+os.environ['STORAGE_ACCOUNT']+".blob.core.windows.net"
        default_credential = DefaultAzureCredential()
        blob_service_client = BlobServiceClient(account_url, credential=default_credential)
        now = datetime.now()
        timefix=int(os.environ['TIMEFIX'])
        if timefix is None:
            timefix=2
        now = now + timedelta(hours=timefix)
        date_time_str = now.strftime("%d-%m-%Y-%H:%M:%S")
        filename=os.environ['ACCOUNT']+"-"+date_time_str+".cef"
        logging.info("going to write "+filename)
        blob_client = blob_service_client.get_blob_client(container=os.environ["CONTAINER"], blob=filename)
        logging.info("going to write to blob")
        blob_client.upload_blob(data)
        logging.info("done uploading")
    