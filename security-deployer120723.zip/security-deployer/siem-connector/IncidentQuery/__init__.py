
import logging
import azure.functions as func
import os
from .lib.query import runQuery
from .lib.process import process
import datetime as dt


def main(mytimer: func.TimerRequest) -> None:
   
    utc_timestamp = dt.datetime.utcnow().replace(tzinfo=dt.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)
    logging.info("Running Query")
    results=runQuery()
    process(results)
   
    
