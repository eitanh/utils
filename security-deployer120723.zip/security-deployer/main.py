from art import *
import subprocess
from lib.spin import spin
from lib.siem import *
from lib.azure import login
subprocess.run(["powershell","cls"])
tprint("Security Deployer",font="colossal ")
login()
deploy_siem_connector()

